const { Telegraf } = require('telegraf');
const session = require('telegraf/session');
const { registerCommands } = require('./commands');

const bot = new Telegraf('YOUR_TELEGRAM_BOT_TOKEN');
bot.use(session());

registerCommands(bot);

bot.launch().then(() => {
    console.log('Telegram bot is up and running');
});

process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));